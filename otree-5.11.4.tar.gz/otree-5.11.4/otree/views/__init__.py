from otree.views.abstract import WaitPage, Page
